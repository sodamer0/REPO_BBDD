insert into Hoteles values (1,'Hotel H10 Costa Adeje')
insert into Hoteles values (2,'Hotel Sheraton La Caleta')
insert into Hoteles values (3,'Hotel Jardines del Teide')



insert into Clientes values (1,'Josue','Melgarejo','Perez',1)
insert into Clientes values (2,'Nayra','Garcia','Rodriguez',1)
insert into Clientes values (3,'Mercedes','Rodriguez','Ruiz',1)
insert into Clientes values (4,'Victor','Martin','Martin',2)
insert into Clientes values (5,'Roberto ','Gonzalez','Perez',2)
insert into Clientes values (6,'Carlos','Medina','Suarez',2)
insert into Clientes values (7,'Iria','Melgarejo','Garcia',3)
insert into Clientes values (8,'Andrea','Rodriguez','Ruiz',3)
insert into Clientes values (9,'Jafet','Gonzalez','Diaz',3)
insert into Clientes values (10,'Jorge','Gonzalez','Escolar',1)
insert into Clientes values (11,'Alejandro','Ramos','Perez',2)
insert into Clientes values (12,'Judit','Melgarejo','Perez',3)


insert into Conductores values (1,'Raymundo','Perez Sigut')
insert into Conductores values (2,'Gregorio','Sigut Perez')
insert into Conductores values (3,'Salvador','Gutierrez Martinez')


insert into Transportes values ('20150617','1234JKL',1)
insert into Transportes values ('20150620','1234JKL',1)
insert into Transportes values ('20150620','4321POI',2)
insert into Transportes values ('20150620','9874QWE',3)
insert into Transportes values ('20150621','1234JKL',3)
insert into Transportes values ('20150621','9874QWE',1)
insert into Transportes values ('20150621','4321POI',2)


insert into Vehiculos values ('1234JKL','Land Rover')
insert into Vehiculos values ('4321POI','Hammer')
insert into Vehiculos values ('9874QWE','Jeep')


insert into Excursiones values (1,'20150617','1234JKL')
insert into Excursiones values (1,'20150620','1234JKL')
insert into Excursiones values (1,'20150621','4321POI')
insert into Excursiones values (2,'20150620','1234JKL')
insert into Excursiones values (3,'20150620','1234JKL')
insert into Excursiones values (3,'20150621','4321POI')
insert into Excursiones values (4,'20150620','1234JKL')
insert into Excursiones values (5,'20150620','9874QWE')
insert into Excursiones values (6,'20150620','9874QWE')
insert into Excursiones values (7,'20150620','9874QWE')
insert into Excursiones values (7,'20150621','4321POI')
insert into Excursiones values (8,'20150620','9874QWE')
insert into Excursiones values (9,'20150620','4321POI')
insert into Excursiones values (10,'20150620','4321POI')
insert into Excursiones values (11,'20150620','4321POI')
insert into Excursiones values (12,'20150620','4321POI')
insert into Excursiones values (12,'20150621','4321POI')